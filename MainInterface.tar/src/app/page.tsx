'use client';

import { useState, useEffect } from 'react';

export default function Home() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 overflow-hidden relative font-sans">
      {/* Futuristic Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            radial-gradient(circle at 25% 25%, #22367b 1px, transparent 1px),
            radial-gradient(circle at 75% 75%, #96e83b 1px, transparent 1px),
            linear-gradient(45deg, #22367b 1px, transparent 1px),
            linear-gradient(-45deg, #00b0d7 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px, 60px 60px, 40px 40px, 40px 40px',
          backgroundPosition: '0 0, 30px 30px, 0 0, 20px 20px'
        }} />
      </div>
      
      {/* Animated gradient overlay for futuristic feel */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/20 via-transparent to-purple-50/20 animate-pulse" style={{ animationDuration: '8s' }} />
      
      {/* Subtle floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-gradient-to-r from-blue-400/20 to-purple-400/20 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 6}s`,
              animationDuration: `${4 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* Connection Lines - BEHIND ALL NODES with perfect alignment */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10">
        {/* Desktop lines - perfectly aligned with enhanced dynamic animation */}
        <svg className="absolute w-full h-full hidden lg:block" style={{ width: '900px', height: '420px', left: '-450px', top: '-210px' }}>
          {/* Left connection line */}
          <line 
            x1="450" 
            y1="130" 
            x2="225" 
            y2="290" 
            stroke="url(#gradient1)" 
            strokeWidth="3" 
            className="drop-shadow-lg"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="3;5;3"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="225" cy="290" r="6" fill="url(#gradient1)" className="drop-shadow-lg">
            <animate
              attributeName="r"
              values="6;8;6"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Center connection line */}
          <line 
            x1="450" 
            y1="130" 
            x2="450" 
            y2="290" 
            stroke="url(#gradient2)" 
            strokeWidth="3" 
            className="drop-shadow-lg"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="3;5;3"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              begin="0.7s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="450" cy="290" r="6" fill="url(#gradient2)" className="drop-shadow-lg">
            <animate
              attributeName="r"
              values="6;8;6"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Right connection line */}
          <line 
            x1="450" 
            y1="130" 
            x2="675" 
            y2="290" 
            stroke="url(#gradient3)" 
            strokeWidth="3" 
            className="drop-shadow-lg"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="3;5;3"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              begin="1.4s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="675" cy="290" r="6" fill="url(#gradient3)" className="drop-shadow-lg">
            <animate
              attributeName="r"
              values="6;8;6"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Define gradients */}
          <defs>
            <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22367b">
                <animate attributeName="stop-color" values="#22367b;#96e83b;#22367b" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#96e83b">
                <animate attributeName="stop-color" values="#96e83b;#22367b;#96e83b" dur="3s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
            <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00b0d7">
                <animate attributeName="stop-color" values="#00b0d7;#22367b;#00b0d7" dur="3s" begin="1s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#22367b">
                <animate attributeName="stop-color" values="#22367b;#00b0d7;#22367b" dur="3s" begin="1s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
            <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#96e83b">
                <animate attributeName="stop-color" values="#96e83b;#00b0d7;#96e83b" dur="3s" begin="2s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#00b0d7">
                <animate attributeName="stop-color" values="#00b0d7;#96e83b;#00b0d7" dur="3s" begin="2s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
          </defs>
        </svg>

        {/* Tablet lines - perfectly aligned with enhanced dynamic animation */}
        <svg className="absolute w-full h-full hidden md:block lg:hidden" style={{ width: '700px', height: '480px', left: '-350px', top: '-240px' }}>
          {/* Left connection line */}
          <line 
            x1="350" 
            y1="110" 
            x2="175" 
            y2="340" 
            stroke="url(#tabletGradient1)" 
            strokeWidth="2.5" 
            className="drop-shadow-md"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="2.5;4;2.5"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="175" cy="340" r="5" fill="url(#tabletGradient1)" className="drop-shadow-md">
            <animate
              attributeName="r"
              values="5;7;5"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Center connection line */}
          <line 
            x1="350" 
            y1="110" 
            x2="350" 
            y2="340" 
            stroke="url(#tabletGradient2)" 
            strokeWidth="2.5" 
            className="drop-shadow-md"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="2.5;4;2.5"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              begin="0.7s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="350" cy="340" r="5" fill="url(#tabletGradient2)" className="drop-shadow-md">
            <animate
              attributeName="r"
              values="5;7;5"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Right connection line */}
          <line 
            x1="350" 
            y1="110" 
            x2="525" 
            y2="340" 
            stroke="url(#tabletGradient3)" 
            strokeWidth="2.5" 
            className="drop-shadow-md"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="2.5;4;2.5"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              begin="1.4s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="525" cy="340" r="5" fill="url(#tabletGradient3)" className="drop-shadow-md">
            <animate
              attributeName="r"
              values="5;7;5"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Define tablet gradients */}
          <defs>
            <linearGradient id="tabletGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22367b">
                <animate attributeName="stop-color" values="#22367b;#96e83b;#22367b" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#96e83b">
                <animate attributeName="stop-color" values="#96e83b;#22367b;#96e83b" dur="3s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
            <linearGradient id="tabletGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00b0d7">
                <animate attributeName="stop-color" values="#00b0d7;#22367b;#00b0d7" dur="3s" begin="1s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#22367b">
                <animate attributeName="stop-color" values="#22367b;#00b0d7;#22367b" dur="3s" begin="1s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
            <linearGradient id="tabletGradient3" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#96e83b">
                <animate attributeName="stop-color" values="#96e83b;#00b0d7;#96e83b" dur="3s" begin="2s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#00b0d7">
                <animate attributeName="stop-color" values="#00b0d7;#96e83b;#00b0d7" dur="3s" begin="2s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
          </defs>
        </svg>

        {/* Mobile lines - simplified but aligned with enhanced dynamic animation */}
        <svg className="absolute w-full h-full md:hidden" style={{ width: '240px', height: '560px', left: '-120px', top: '-280px' }}>
          {/* Top to middle connection */}
          <line 
            x1="120" 
            y1="90" 
            x2="120" 
            y2="240" 
            stroke="url(#mobileGradient1)" 
            strokeWidth="2" 
            className="drop-shadow-sm"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="2;3;2"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="120" cy="240" r="4" fill="url(#mobileGradient1)" className="drop-shadow-sm">
            <animate
              attributeName="r"
              values="4;6;4"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Middle to bottom connections */}
          <line 
            x1="120" 
            y1="240" 
            x2="70" 
            y2="390" 
            stroke="url(#mobileGradient2)" 
            strokeWidth="2" 
            className="drop-shadow-sm"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="2;3;2"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              begin="0.7s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="70" cy="390" r="3" fill="url(#mobileGradient2)" className="drop-shadow-sm">
            <animate
              attributeName="r"
              values="3;5;3"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              begin="0.7s"
              repeatCount="indefinite"
            />
          </circle>
          
          <line 
            x1="120" 
            y1="240" 
            x2="170" 
            y2="390" 
            stroke="url(#mobileGradient3)" 
            strokeWidth="2" 
            className="drop-shadow-sm"
          >
            <animate
              attributeName="stroke-dasharray"
              values="0 1000;1000 0"
              dur="2s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="stroke-width"
              values="2;3;2"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.6;1;0.6"
              dur="2s"
              begin="1.4s"
              repeatCount="indefinite"
            />
          </line>
          <circle cx="170" cy="390" r="3" fill="url(#mobileGradient3)" className="drop-shadow-sm">
            <animate
              attributeName="r"
              values="3;5;3"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.8;1;0.8"
              dur="1.5s"
              begin="1.4s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* Define mobile gradients */}
          <defs>
            <linearGradient id="mobileGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22367b">
                <animate attributeName="stop-color" values="#22367b;#96e83b;#22367b" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#96e83b">
                <animate attributeName="stop-color" values="#96e83b;#22367b;#96e83b" dur="3s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
            <linearGradient id="mobileGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00b0d7">
                <animate attributeName="stop-color" values="#00b0d7;#22367b;#00b0d7" dur="3s" begin="1s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#22367b">
                <animate attributeName="stop-color" values="#22367b;#00b0d7;#22367b" dur="3s" begin="1s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
            <linearGradient id="mobileGradient3" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#96e83b">
                <animate attributeName="stop-color" values="#96e83b;#00b0d7;#96e83b" dur="3s" begin="2s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#00b0d7">
                <animate attributeName="stop-color" values="#00b0d7;#96e83b;#00b0d7" dur="3s" begin="2s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Main container with optimal spacing */}
      <div className="relative z-20 min-h-screen flex flex-col items-center justify-center p-6 md:p-10">
        
        {/* Main Clevio Node - Optimized spacing */}
        <div className={`relative mb-20 md:mb-28 transition-all duration-1000 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="relative bg-white rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 px-16 py-10 md:px-20 md:py-12 border border-gray-100" style={{ width: '450px', height: '220px' }}>
            {/* Subtle gradient overlay for elegance */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-50/50 to-purple-50/50" />
            
            {/* Network/Hierarchy icon at top */}
            <div className="absolute top-8 left-1/2 transform -translate-x-1/2 z-10">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#22367b" strokeWidth="2.5">
                <circle cx="12" cy="5" r="3"/>
                <circle cx="5" cy="19" r="3"/>
                <circle cx="19" cy="19" r="3"/>
                <line x1="12" y1="8" x2="12" y2="16"/>
                <line x1="8" y1="17" x2="5" y2="19"/>
                <line x1="16" y1="17" x2="19" y2="19"/>
              </svg>
            </div>
            
            <div className="text-center mt-10 z-10 relative">
              {/* Logo/Brand */}
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#22367b] mb-4 tracking-tight">
                clevio
              </h1>
              
              {/* Tagline */}
              <p className="text-lg md:text-xl text-gray-600 font-light tracking-wide">
                Clever . Leverage . Input . Output
              </p>
            </div>
          </div>
        </div>

        {/* Child Cards Container - Optimized spacing */}
        <div className={`flex flex-col lg:flex-row gap-8 md:gap-12 lg:gap-20 items-center justify-center w-full max-w-7xl transition-all duration-1000 delay-300 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          
          {/* Left Card - Innovator Camp */}
          <div 
            className="relative bg-white rounded-2xl shadow-lg p-10 md:p-12 w-full max-w-md border border-gray-100"
            style={{ zIndex: 10 }}
          >
            {/* Light bulb icon */}
            <div className="flex justify-center mb-6 relative z-10">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#22367b" strokeWidth="2.5">
                <path d="M12 2v7m0 0a4 4 0 1 0 0 8c1.5 0 2.9-.6 3.9-1.7"/>
                <path d="M12 9v3"/>
                <path d="M8 21h8"/>
                <path d="M12 17v4"/>
              </svg>
            </div>
            
            <div className="text-center relative z-10">
              <h3 className="text-xl md:text-2xl font-bold text-[#22367b] mb-4 uppercase tracking-wide">
                clevio INNOVATOR CAMP
              </h3>
              
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
              
              <button 
                onClick={() => window.location.href = '/innovator-camp'}
                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-semibold py-3 px-8 rounded-full transform transition-all duration-200 hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
              >
                Explore
              </button>
            </div>
          </div>

          {/* Center Card - AI Assistants */}
          <div 
            className="relative bg-white rounded-2xl shadow-lg p-10 md:p-12 w-full max-w-md border border-gray-100"
            style={{ zIndex: 10 }}
          >
            {/* AI/Robot icon */}
            <div className="flex justify-center mb-6 relative z-10">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#22367b" strokeWidth="2.5">
                <rect x="3" y="11" width="18" height="10" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            
            <div className="text-center relative z-10">
              <h3 className="text-xl md:text-2xl font-bold text-[#22367b] mb-4 uppercase tracking-wide">
                clevio AI ASSISTANTS
              </h3>
              
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
              
              <button 
                onClick={() => window.location.href = '/ai-assistants'}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold py-3 px-8 rounded-full transform transition-all duration-200 hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
              >
                Explore
              </button>
            </div>
          </div>

          {/* Right Card - Innovator Pro */}
          <div 
            className="relative bg-white rounded-2xl shadow-lg p-10 md:p-12 w-full max-w-md border border-gray-100"
            style={{ zIndex: 10 }}
          >
            {/* Lightning bolt icon */}
            <div className="flex justify-center mb-6 relative z-10">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#22367b" strokeWidth="2.5">
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
              </svg>
            </div>
            
            <div className="text-center relative z-10">
              <h3 className="text-xl md:text-2xl font-bold text-[#22367b] mb-4 uppercase tracking-wide">
                clevio INNOVATOR PRO
              </h3>
              
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
              
              <button 
                onClick={() => window.location.href = '/innovator-pro'}
                className="bg-gradient-to-r from-lime-400 to-emerald-600 hover:from-lime-500 hover:to-emerald-700 text-white font-semibold py-3 px-8 rounded-full transform transition-all duration-200 hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
              >
                Explore
              </button>
            </div>
          </div>
        </div>

        {/* Footer Text - Optimized spacing */}
        <div className={`mt-20 md:mt-24 transition-all duration-1000 delay-500 ${mounted ? 'opacity-100' : 'opacity-0'}`}>
          <p className="text-sm md:text-base text-gray-500 uppercase tracking-widest font-light">
            INNOVATION AT YOUR FINGERTIPS
          </p>
        </div>
      </div>

      {/* Enhanced animation styles */}
      <style jsx>{`
        @keyframes subtle-float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-4px); }
        }
        
        @keyframes gentle-breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.01); }
        }
        
        @keyframes shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        
        /* Enhanced hover effects */
        .hover\\:-translate-y-3:hover {
          animation: subtle-float 6s ease-in-out infinite;
        }
        
        /* Background pattern animation */
        @keyframes pattern-drift {
          0% { background-position: 0 0, 30px 30px, 0 0, 20px 20px; }
          100% { background-position: 60px 60px, 90px 90px, 40px 40px, 60px 60px; }
        }
        
        /* Performance optimizations */
        .transform {
          will-change: transform;
        }
        
        /* Enhanced shadow effects */
        .shadow-xl {
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        
        .hover\\:shadow-xl:hover {
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
      `}</style>
    </main>
  );
}